package AssistedProject;
class StudentDetails{
	StudentDetails(int rollno,String name)
	{
		System.out.println("Student Details :"+" "+rollno+" "+name);
	}
}
public class ParameterizedConstructor {
	public static void main(String[] args) {
		StudentDetails st =new StudentDetails(191,"Ashok");
		StudentDetails st1 =new StudentDetails(192,"Arun");
		StudentDetails st2 =new StudentDetails(193,"Bala");
	}

}
