package AssistedProject;
class SalaryDetails{
	int salarydetails(int salary,int bonus)
	{
		return salary+bonus;
	}
}
public class Methoddemo {
	public static void main(String[] args) {
		int d;
		SalaryDetails sc=new SalaryDetails();
		d=sc.salarydetails(20000,2000);
		System.out.println("Total Salary is : " +d);
		
	}

}
