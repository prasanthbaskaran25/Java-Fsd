package AssistedProject2;
class Bike2{
	int speed=200;
	void display() {
		System.out.println("Speed of Bike :"+speed);
	}
}
class R152 extends Bike2{
	int speed=300;
	void speedOfR15() {
		speed=super.speed+120;
		System.out.println(speed);
	}
	
}
class YamahanewR152 extends Bike2{
	void speedofnewR15() {
		System.out.println(speed+200);
	}
}
public class Inheritance {
public static void main(String[] args) {
	R152 r15= new R152();
	r15.display();
	r15.speedOfR15();
	
	YamahanewR152 newr15=new YamahanewR152();
	newr15.speedofnewR15();
	
	
}	
}