package AssistedProject;
import java.util.*;
public class Collection {
	public static void main(String[] args) {
	
		System.out.println("ArrayList");
		ArrayList<String> city=new ArrayList<String>();   
	      city.add("Namakkal");//
	      city.add("Erode");    	   
	      System.out.println(city);  
		
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vec = new Vector();
	      vec.addElement(20); 
	      vec.addElement(40); 
	      System.out.println(vec);
		
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("Dino");  
	      names.add("Sam");  	      
	      Iterator<String> itr=names.iterator();  
	      while(itr.hasNext()){  
	      System.out.println(itr.next());  
	       
	       System.out.println("\n");
	       System.out.println("HashSet");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(500);  
	       set.add(600);  
	       set.add(700);
	       set.add(800);
	       set.add(900);
	       System.out.println(set);
	       
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(21);  
	       set2.add(22);  
	       set2.add(23);
	       set2.add(24);	       
	       System.out.println(set2);
	      	} 
	      }  

}