package AssistedProject2;
class Demo{
	void args() {
		System.out.println("no args");
	}
	void args(int a,int b)
	{
		System.out.println("2 args of int");
	}
	void args(double a ,double b)
	{
		System.out.println("2 args of double");
	}
}
public class Polymorphism {
public static void main(String[] args) {
	Demo dm=new Demo();
	dm.args(5,6.0);
	dm.args(5.5,5.7);
	dm.args();
	dm.args(6, 7);
	dm.args(5.6,7);

}
}