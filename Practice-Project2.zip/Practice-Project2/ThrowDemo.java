package AssistedProject2;

public class ThrowDemo {
public static void main(String[] args) {
	int age=17;
	try {
		if(age>=18){
			System.out.println("Right to Vote");	
		}
		else{
			throw new ArithmeticException("The age is not matching with the right to vote");
		}
	}
	catch(Exception ex){
		System.out.println(ex.getMessage());
	}
}
}
