package com.example;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.BeforeTest;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.Parameters;

public class Testing {
	 WebDriver wd;

		@BeforeTest
		@Parameters("browser")
		public void beforeClass(String browser)
		{
			switch(browser) {
			
				case "chrome": WebDriverManager.chromedriver().setup();
				wd=new ChromeDriver();
				break;
				case "firefox": WebDriverManager.firefoxdriver().setup();
				wd=new FirefoxDriver();
				break;
			}
			wd.manage().window().maximize();
		}


	@AfterTest
	public void afterClass() {
		wd.close();
	}

	@Test(priority = 1)
	@Parameters("url")
	public void navigator(String url) throws InterruptedException, IOException {
		 long start = System.currentTimeMillis();
		wd.get(url);
		screenshot(wd,"navigator");
		  long finish = System.currentTimeMillis();
		  long totalTime = finish - start; 
		  System.out.println(totalTime);
		  System.out.println("Total Time for page load - "+totalTime); 
		  
		  wd.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
		  
		  screenshot(wd,"navigator");
	}

	@Test(priority = 2)
	@Parameters("url")
	public void scroll() throws InterruptedException, IOException {

		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) wd;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		System.out.println("\nNavigated to bottom of the page");
		screenshot(wd,"scroll");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,-document.body.scrollHeight)", "");
		System.out.println("\nScroll Feature available");
		Thread.sleep(2000);
		
	}
	  @Test(priority=3)
	  @Parameters("url")
	  public void checkscroll() throws IOException {
		
		  String execscript="return document.documentElement.scrollHeight>document.documentElement.clientHeight;";
		  JavascriptExecutor scrollbar = (JavascriptExecutor) wd;
		  Boolean test=(Boolean)(scrollbar.executeScript(execscript));
		  if(test==true) {
			  System.out.println("Scroll bar is present");
		  }
		  else {
			  System.out.println("Scroll bar is not present");
		  }
		  screenshot(wd,"scrollbar");
		  
	  }

	@Test(priority = 4)
	@Parameters("url")
	public void searchProduct() throws InterruptedException, IOException {
		Thread.sleep(1000);
		wd.findElement(By.className("_3704LK")).sendKeys("iPhone 13");
		  wd.findElement(By.className("_34RNph")).click();
		  screenshot(wd,"searchproduct");
	}

	@Test(priority = 5)
	public void loadImage() throws InterruptedException, IOException {

		String url1 = "https://www.flipkart.com/apple-iphone-13-blue-256-gb/p/itmd68a015aa1e39?pid=MOBG6VF566ZTUVFR&lid=LSTMOBG6VF566ZTUVFR2RQLVU&marketplace=FLIPKART&q=iPhone+13&store=tyy%2F4io&srno=s_1_8&otracker=search&otracker1=search&fm=organic&iid=1c0c7402-fe4f-4f45-9aa8-cc59dffe8503.MOBG6VF566ZTUVFR.SEARCH&ppt=hp&ppn=homepage&ssid=i4t60bsv4g0000001665375424769&qH=c3d519be0191fbf8";
		wd.get(url1);
		Thread.sleep(3000);
		//driver.navigate().refresh();

		Wait<WebDriver> wait = new FluentWait<WebDriver>(wd).withTimeout(10, TimeUnit.SECONDS)
				.pollingEvery(2, TimeUnit.SECONDS).ignoring(NoSuchElementException.class); 
		wait.until(new Function<WebDriver, WebElement>() {

			@Test
			public WebElement apply(WebDriver driver) {
				WebElement img = driver.findElement(By.xpath(
						"//*[@id=\"container\"]/div/div[3]/div[1]/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/img"));

				if (img.isDisplayed()) {
					System.out.println("\nImage Loaded");
					return img;
				} else {
					System.out.println("\nFluent Wait Fail!, Element Not Loaded Yet");
					return null;
				}
			}
		});
		screenshot(wd,"pageLoad");
	}

	@Test(priority = 6)
	@Parameters("url")
	public void scrollFrequency() throws InterruptedException, IOException {
		Thread.sleep(2000);
		long start = System.currentTimeMillis();
		WebElement element = wd.findElement(By.cssSelector(
				"#container > div > div._2c7YLP.UtUXW0._6t1WkM._3HqJxg > div._1YokD2._2GoDe3 > div._1YokD2._3Mn1Gg.col-8-12 > div._1YokD2._3Mn1Gg > div:nth-child(7) > div > div:nth-child(3) > div > div > div:nth-child(1)"));
		((JavascriptExecutor) wd).executeScript("arguments[0].scrollIntoView(true);", element);
		long stop = System.currentTimeMillis();
		long totalTime = stop - start;
		System.out.println("\nScroll Frequency in millisecs - " + totalTime);
		screenshot(wd,"scrollfrequency");

	}

	@Test(priority = 7)
	@Parameters("url")
	public void downloadImages() throws InterruptedException, IOException {
		WebElement img = wd.findElement(By
				.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/img"));
		Boolean p = (Boolean) ((JavascriptExecutor) wd).executeScript("return arguments[0].complete "
				+ "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0", img);

		if (p) {
			System.out.println("\nImage present");
		} else {
			System.out.println("\nImage not present");
		}
		screenshot(wd,"downloadImages");
	}

	@Test(priority = 8)
	@Parameters("url")
	public void screenResolution() throws InterruptedException, IOException {
		Thread.sleep(1000);
		Dimension dimension = new Dimension(720, 1080);
		wd.manage().window().setSize(dimension);
		Thread.sleep(3000);

		Dimension dimension1 = new Dimension(1280, 800);
		wd.manage().window().setSize(dimension1);
		Thread.sleep(3000);

		Dimension dimension2 = new Dimension(2256, 1504);
		wd.manage().window().setSize(dimension2);

		JavascriptExecutor js = (JavascriptExecutor) wd;
		int contentHeight = ((Number) js.executeScript("return window.innerHeight")).intValue();
		int contentWidth = ((Number) js.executeScript("return window.innerWidth")).intValue();
		System.out.println("\nHeight: " + contentHeight + " Width: " + contentWidth + "\n");
		screenshot(wd,"screenshotResolution");

	}
	
	
	public static void screenshot(WebDriver driver,String screenshotName) throws IOException{
		  TakesScreenshot ts = (TakesScreenshot)driver;
		   File src=((TakesScreenshot)ts).getScreenshotAs(OutputType.FILE);
			org.apache.commons.io.FileUtils.copyFile(src,new File("D:\\WorkSpace of STS\\Phase-5 Practice Project\\" +screenshotName+".png"));
	}
	
	
	

}


