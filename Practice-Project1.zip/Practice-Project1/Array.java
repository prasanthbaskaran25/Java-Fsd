package AssistedProject;

import java.util.Scanner;

public class Array {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int size;
		System.out.println("One Dimensional Array");
		System.out.println("Array Size");
		size=sc.nextInt();
		int a[]=new int[size];
		for(int i=0;i<size;i++)
		{
			System.out.println("enter the index "+i);
			a[i]=sc.nextInt();
		}
		for(int aa:a)
		{
			System.out.println(aa);
		}
		System.out.println("\n");
		System.out.println("Enter the row size of an array");
		int row=sc.nextInt();
		System.out.println("Enter the column size of an array");
		int col=sc.nextInt();
		int b[][]=new int[row][col];
		for (int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.println("enter the value"+i+","+j);
				b[i][j]=sc.nextInt();
			}
		}
		for (int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(b[i][j]+" ");
				
			}
			System.out.print("\n");
		}
		
	}

}
