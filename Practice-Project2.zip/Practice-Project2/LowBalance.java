package AssistedProject2;

public class LowBalance extends Exception {
	LowBalance(String a)
	{
		super(a);
	}
}
