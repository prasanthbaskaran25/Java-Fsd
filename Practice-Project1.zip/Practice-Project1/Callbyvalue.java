package AssistedProject;
class IncomeDetails{
	int salary =20000;
	int bonus(int a)
	{
		int amount;
		amount=salary+a;
		return amount;
	}
}
public class Callbyvalue {
	public static void main(String[] args) {
	IncomeDetails sc=new IncomeDetails();
	System.out.println("Total Salary is : "+sc.bonus(2500));
	}

}
