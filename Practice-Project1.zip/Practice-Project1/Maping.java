package AssistedProject;
import java.util.*;
public class Maping
{
	public static void main(String[] args) 
	{
		
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"Vishnu");    
		      hm.put(2,"Hari");    
		      hm.put(3,"Dino");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry m:hm.entrySet())
		      {    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		      
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"Ashok");  
		      ht.put(5,"Saran");  
		      ht.put(6,"Kavin");  
		      ht.put(7,"Alaganad");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry n:ht.entrySet())
		      {    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"Raja");    
		      map.put(9,"Praveen");    
		      map.put(10,"Ravi");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Map.Entry l:map.entrySet())
		      {    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		  }  
	}


