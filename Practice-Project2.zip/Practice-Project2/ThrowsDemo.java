package AssistedProject2;

public class ThrowsDemo {
	public static int display (int a,int b) throws ArithmeticException
	{
		int c;
		c=a/b;
		return c;
	}
	public static void main(String[] args) {
		ThrowsDemo o=new ThrowsDemo();
		try {
			System.out.println(o.display(200,0));
		}
		catch(ArithmeticException e){
			System.out.println("Error : "+e.getMessage());
		}
	}

}
