package AssistedProject;
class Square{
	Square()
	{
		int side1=3;
		int side2=5;
		System.out.println("Area of a Square is "+side1*side1);
		System.out.println("Area of a Square is "+side2*side2);
	}
}
public class DefaultConstructor {
	public static void main(String[] args) {
	Square sq=new Square();
	}
}
