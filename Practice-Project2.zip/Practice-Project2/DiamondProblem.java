package AssistedProject2;

interface Calculator1{
	public abstract void sum(int a, int b);
	public abstract void sub(int a, int b);
}
interface Calculator2 extends Calculator1{
	public abstract void mul(int a, int b);
}
interface Calculator3{
	public abstract void div(int a, int b);

}

class Cal implements Calculator3,Calculator2{

	@Override
	public void div(int a, int b) {
		System.out.println(a/b);
		
	}

	@Override
	public void sum(int a, int b) {
		System.out.println(a+b);
		
	}

	@Override
	public void sub(int a, int b) {
		System.out.println(a-b);
		
	}

	@Override
	public void mul(int a, int b) {
		System.out.println(a*b);
		
	}


}
public class DiamondProblem {
 public static void main(String[] args) {
	 		Cal imp=new Cal();
			imp.sum(500, 200);
			imp.sub(1000,200);
			imp.div(25, 5);
			imp.mul(5, 5);
			}

}


