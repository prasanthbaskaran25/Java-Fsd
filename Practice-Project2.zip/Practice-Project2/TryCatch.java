package AssistedProject2;

public class TryCatch {
	public static void main(String[] args) {
		System.out.println("Hai user");
		try {
			int sum=5/0;
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
