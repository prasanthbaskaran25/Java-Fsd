package AssitedProjectDataStructuresArrayandLists;

import java.util.Scanner;

public class SumofNNumber {
public static void main(String[] args) {
	int arr[]=new int[] {3,6,7,8,29,67};
	int sum=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the no.of element to sum");
	int n=sc.nextInt();
	for(int i=0;i<n;i++)
	{
		sum=sum+arr[i];
	}
	System.out.println("Sum of N element is "+sum);
}
}
