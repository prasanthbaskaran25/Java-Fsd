package AssistedProject2;
public class CustomException {
	public static void main(String[] args) throws LowBalance {
		CustomExceptionBank a=new CustomExceptionBank();
		a.processing(20000,30000);
	}

}
