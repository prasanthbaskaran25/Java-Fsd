package AssistedProject;
class Area{
	void area(int l,int b)
	{
		System.out.println("Area of a Reactangle is "+l*b);
	}
	void area(int r)
	{
		System.out.println("Area of a Circle is "+(3.14*r*r));
	}
}
public class MethodOverloading {
public static void main(String[] args) {
	Area aa=new Area();
	aa.area(5,6);
	aa.area(5);
	}
	
}
