package AssistedProject;
import java.util.regex.*;
public class RegularExpression {
	public static void main(String[] args) {

		String pattern = "[a-z]+";
		String check = "Java Phase One";
		Pattern pa = Pattern.compile(pattern);
		Matcher ch = pa.matcher(check);
		
		while (ch.find())
	      	System.out.println( check.substring( ch.start(), ch.end() ) );
		}
}



