package AssistedProject2;

abstract class Calculator{
	public abstract void sum(int a, int b);
	public abstract void sub(int a, int b);
	public abstract void mul(int a, int b);
	public abstract void div(int a, int b);
}

class CalImp extends Calculator{

	@Override
	public void sum(int a, int b) {
		System.out.println(a+b);
	}

	@Override
	public void sub(int a, int b) {
		System.out.println(a-b);
	}

	@Override
	public void mul(int a, int b) {
		System.out.println(a*b);
		
	}

	@Override
	public void div(int a, int b) {
		System.out.println(a/b);
		
	}
}
public class Abstraction {
	public static void main(String[] args) {
		CalImp imp=new CalImp();
		imp.sum(500, 200);
		imp.sub(1000,200);
		imp.mul(55, 40);
		imp.div(25, 5);
	}
}

