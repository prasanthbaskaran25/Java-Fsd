package AssistedProject2;
class Seq implements Runnable{

	@Override
	public void run() {
		num();
		
	}
	   void num(){
	   for(int i=0;i<9;i++)
		{
			System.out.println(i);
		}
	  }
	 
}
public class RunnableInterface {
	public static void main(String[] args) {
		Seq num=new Seq();
		Thread t=new Thread(num);
		t.start();
	}

}