package AssistedProject;

public class Accessmodifiers {
	void methodDefault()
	{
		System.out.println("Accessed in a default method");
	}
	public void methodPublic()
	{
		System.out.println("Accessed in a public method");
	}
	private void methodPrivate()
	{
		System.out.println("Accessed in a private method");
	}
	protected void methodProtected()
	{
		System.out.println("Accessed in a protected method");
	}
	public static void main(String[] args) {
	Accessmodifiers obj=new Accessmodifiers();
	obj.methodDefault();
	obj.methodPublic();
	obj.methodPrivate();
	obj.methodProtected();
	}

}
