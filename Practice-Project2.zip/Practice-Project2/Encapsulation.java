package AssistedProject2;

public class Encapsulation {
 public static void main(String[] args) {
	Encapsulation1 obj=new Encapsulation1();
	Encapsulation1 obj1=new Encapsulation1();
	obj.setId(100);
	obj.setName("Rockey");
	obj1.setId(200);
	obj1.setName("Vishnu");
	System.out.println(obj+"\n"+obj1);
}
}
