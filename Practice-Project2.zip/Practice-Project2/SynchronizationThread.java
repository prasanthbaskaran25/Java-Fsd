package AssistedProject2;

class OddEven implements Runnable{
	public void run() {
		numOdd();
		numEven();
	}
		synchronized void numOdd() {//without synchronized by using voidnumOdd()
		for(int i=1;i<9;i=i+2)
		{
			System.out.println(i);
		}
	}
        synchronized void numEven() {//without synchronized by using voidnumEven()
		for(int i=2;i<9;i+=2)
		{
			System.out.println(i);
		}
	}
}
public class SynchronizationThread {
	public static void main(String[] args) {
		OddEven num1=new OddEven();
		Thread t1=new Thread(num1);
		Thread t2=new Thread(num1);
		t1.start();
		t2.start();
	}

}
