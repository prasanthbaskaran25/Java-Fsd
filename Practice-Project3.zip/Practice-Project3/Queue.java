package AssitedProjectDataStructuresArrayandLists;

import java.util.Scanner;

public class Queue {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the size of the queue");
	int size=sc.nextInt();
	int Queue[]=new int [size];
	int front  =-1,rear=-1;
	System.out.println("Q operation");
	while(true) {
		System.out.println("Enter ur choice 1.enqueue 2.dequeue 3.display 4.exit);");
		int ch=sc.nextInt();
		switch(ch) {
		case 1:if(rear==size-1){

		System.out.println("Q is full no more insertion");
		}
		else{
			System.out.println("Enter the element to insert");
			int k=sc.nextInt();
			rear++;
			front=0;
			Queue[rear]=k;
		}
		break;
		case 2:if((front==-1&&rear==-1)||(front>rear)) {
			System.out.println("Q is empty no deletion operation");
		}
		else {
			front=front+1;
		}
		break;
		case 3:if((front==-1&&rear==-1)||(front>rear)) {
			System.out.println("Q is empty ");
		}
		else {
			for(int i=front;i<=rear;i++) {
				System.out.println(Queue[i]);
			}
		}
		case 4:System.exit(0);
		break;
		default:System.out.println("Check ur choice");
		break;
	}
}
}
}
