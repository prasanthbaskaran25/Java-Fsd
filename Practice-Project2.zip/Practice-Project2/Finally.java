package AssistedProject2;

public class Finally {
	public static void main(String[] args) {
		System.out.println("Hai user");
		try {
			int sum=5/0;
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("Welcome to Java FSD");
		}
		
	}
}
