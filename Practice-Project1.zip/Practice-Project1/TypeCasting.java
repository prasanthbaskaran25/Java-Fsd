package AssistedProject;

public class TypeCasting {
	public static void main(String[] args) {
		//Implicit conversion
		System.out.println("Implicit Typecasting");
		char a='P';
		System.out.println("Value of a : "+a);
		int b=a;
		System.out.println("Value of b : "+b);
		float c=a;
		System.out.println("Value of c : "+c);
		float d=a;
		System.out.println("Value of d : "+d);
		double e=a;
		System.out.println("Value of e : "+e);
		System.out.println("\n");
		System.out.println("Explicit Typecasting");
		//Explicit conversion
		double x=45.68;
		int y=(int)x;
		System.out.println("Value of x : "+x);
		System.out.println("Value of y : "+y);	
	}	
}
