package AssistedProject2;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
public class DeleteFile {
	public static void main(String[] args) throws IOException {
		String path="D:\\FileHandling\\";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a file name");
		String filename =sc.next();
		String finalpath=path+filename;
		System.out.println(finalpath);
		boolean b=Files.deleteIfExists(Paths.get(finalpath)); 
		if(b!=true)
		{
			System.out.println("File is not Deleted");
		}
		else
		{
			System.out.println("File is Deleted");
		
		}
	}
}
