package AssistedProject2;
class NumberIteration extends Thread{
	public void run(){
		for(int i=0;i<9;i++)
		{
			System.out.println(i);
		}
	}
	
}
public class ThreadClass {
	public static void main(String[] args) {
		NumberIteration num1=new NumberIteration();
		num1.start();
	}

}
