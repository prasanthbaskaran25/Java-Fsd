package AssistedProject2;

public class CustomExceptionBank {
	void processing(int initalbalance , int withdrawamount) throws LowBalance
	{
	if(withdrawamount<initalbalance)
	{
		System.out.println("Remaining balance :"+(initalbalance-withdrawamount));
	}
	else
	{
		throw new LowBalance("Your balance is low to meet your requirements");
	}
	}
}
